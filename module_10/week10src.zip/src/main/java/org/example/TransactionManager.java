package org.example;

import java.time.LocalDate;
import java.util.*;

public class TransactionManager {
    private final List<ParkingTransaction> transactions;
    private final Map<String, List<ParkingTransaction>> permitTransactions;

    public TransactionManager() {
        this.transactions = new ArrayList<>();
        this.permitTransactions = new HashMap<>();
    }

    public ParkingTransaction park(LocalDate date, ParkingPermit permit, ParkingLot lot) {
        ParkingTransaction transaction = new ParkingTransaction(date, permit, lot);
        transactions.add(transaction);
        
        permitTransactions.computeIfAbsent(permit.getId(), k -> new ArrayList<>()).add(transaction);
        
        lot.entry(permit.getVehicle());
        
        return transaction;
    }

    public Money getParkingCharges(ParkingPermit permit) {
        return getParkingCharges(permit.getId());
    }

    public Money getParkingCharges(String permitId) {
        List<ParkingTransaction> permitTxns = permitTransactions.getOrDefault(permitId, new ArrayList<>());
        
        long totalCents = 0;
        for (ParkingTransaction transaction : permitTxns) {
            totalCents += transaction.getFeeCharged().getCents();
        }
        
        return new Money(totalCents);
    }

    public Money getParkingCharges(Customer customer, PermitManager permitManager) {
        List<ParkingPermit> customerPermits = permitManager.getPermitsByCustomer(customer);
        
        long totalCents = 0;
        for (ParkingPermit permit : customerPermits) {
            totalCents += getParkingCharges(permit).getCents();
        }
        
        return new Money(totalCents);
    }

    public List<ParkingTransaction> getAllTransactions() {
        return new ArrayList<>(transactions);
    }

    public List<ParkingTransaction> getTransactions(ParkingPermit permit) {
        return new ArrayList<>(permitTransactions.getOrDefault(permit.getId(), new ArrayList<>()));
    }

    public List<ParkingTransaction> getTransactionsByLot(ParkingLot lot) {
        List<ParkingTransaction> lotTransactions = new ArrayList<>();
        for (ParkingTransaction transaction : transactions) {
            if (transaction.getLot().equals(lot)) {
                lotTransactions.add(transaction);
            }
        }
        return lotTransactions;
    }
}
