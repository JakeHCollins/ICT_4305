package org.example;

import java.time.Instant;
import java.util.Objects;

public class ParkingCharge {
    private final String permitId;
    private final String lotId;
    private final Instant incurred;
    private final Money amount;
    private final CarType carType;

    public ParkingCharge(String permitId, String lotId, Instant incurred, Money amount, CarType carType) {
        this.permitId = permitId;
        this.lotId = lotId;
        this.incurred = incurred;
        this.amount = amount;
        this.carType = carType;
    }

    public String getPermitId() {
        return permitId;
    }

    public String getLotId() {
        return lotId;
    }

    public Instant getIncurred() {
        return incurred;
    }

    public Money getAmount() {
        if (carType == CarType.COMPACT) {
            return new Money((long)(amount.getCents() * 0.8));
        } else {
            return amount;
        }
    }

    @Override
    public String toString() {
        return "ParkingCharge{" +
                "permitId='" + permitId + '\'' +
                ", lotId='" + lotId + '\'' +
                ", incurred=" + incurred +
                ", amount=" + amount +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ParkingCharge that = (ParkingCharge) obj;
        return Objects.equals(permitId, that.permitId) &&
                Objects.equals(lotId, that.lotId) &&
                Objects.equals(incurred, that.incurred);
    }

    @Override
    public int hashCode() {
        return Objects.hash(permitId, lotId, incurred);
    }
}