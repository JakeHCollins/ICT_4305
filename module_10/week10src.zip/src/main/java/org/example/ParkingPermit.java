package org.example;

import java.time.LocalDate;
import java.util.Objects;
import java.util.UUID;

public class ParkingPermit {
    private final String id;
    private final Car vehicle;
    private final LocalDate expirationDate;
    private final LocalDate registrationDate;

    public ParkingPermit(Car vehicle, LocalDate registrationDate, LocalDate expirationDate) {
        this.id = UUID.randomUUID().toString();
        this.vehicle = vehicle;
        this.registrationDate = registrationDate;
        this.expirationDate = expirationDate;
    }

    public String getId() {
        return id;
    }

    public Car getVehicle() {
        return vehicle;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public boolean isExpired(LocalDate date) {
        return date.isAfter(expirationDate);
    }

    @Override
    public String toString() {
        return "ParkingPermit{" +
                "id='" + id + '\'' +
                ", vehicle=" + vehicle.getLicense() +
                ", registrationDate=" + registrationDate +
                ", expirationDate=" + expirationDate +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ParkingPermit that = (ParkingPermit) obj;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
