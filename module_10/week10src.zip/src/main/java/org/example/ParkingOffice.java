package org.example;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ParkingOffice {
    private final String parkingOfficeName;
    private final Address parkingOfficeAddress;
    private final List<Customer> listOfCustomers;
    private final List<ParkingLot> listOfParkingLots;
    private final PermitManager permitManager;
    private final TransactionManager transactionManager;

    public ParkingOffice(String parkingOfficeName, Address parkingOfficeAddress) {
        this.parkingOfficeName = parkingOfficeName;
        this.parkingOfficeAddress = parkingOfficeAddress;
        this.listOfCustomers = new ArrayList<>();
        this.listOfParkingLots = new ArrayList<>();
        this.permitManager = new PermitManager();
        this.transactionManager = new TransactionManager();
    }

    public Customer register(String name, Address address, String phone) {
        String customerId = "CUSTOMER-" + (listOfCustomers.size() + 1);
        Customer customer = new Customer(customerId, name, address, phone);
        listOfCustomers.add(customer);
        return customer;
    }

    public void register(Customer customer) {
        if (!listOfCustomers.contains(customer)) {
            listOfCustomers.add(customer);
        }
    }

    public ParkingPermit register(Car car) {
        return permitManager.register(car);
    }

    public ParkingPermit registerCar(Customer customer, String license, CarType type) {
        Car car = customer.register(license, type);
        return permitManager.register(car);
    }

    public ParkingTransaction park(LocalDate date, ParkingPermit permit, ParkingLot lot) {
        return transactionManager.park(date, permit, lot);
    }

    public Money getParkingCharges(ParkingPermit permit) {
        return transactionManager.getParkingCharges(permit);
    }

    public Money getParkingCharges(Customer customer) {
        return transactionManager.getParkingCharges(customer, permitManager);
    }


    public void addLot(ParkingLot lot) {
        listOfParkingLots.add(lot);
    }

    public Customer getCustomer(String name) {
        for (Customer customer : listOfCustomers) {
            if (customer.getName().equals(name)) {
                return customer;
            }
        }
        return null;
    }

    public List<String> getCustomerIds() {
        List<String> customerIds = new ArrayList<>();
        for (Customer customer : listOfCustomers) {
            customerIds.add(customer.getCustomerId());
        }
        return customerIds;
    }

    public List<String> getPermitIds() {
        return permitManager.getAllPermitIds();
    }

    public List<String> getPermitIds(Customer customer) {
        if (customer == null) {
            return new ArrayList<>();
        }
        
        List<String> permitIds = new ArrayList<>();
        for (ParkingPermit permit : permitManager.getPermitsByCustomer(customer)) {
            permitIds.add(permit.getId());
        }
        return permitIds;
    }

    public String getParkingOfficeName() {
        return parkingOfficeName;
    }

    public Address getParkingOfficeAddress() {
        return parkingOfficeAddress;
    }

    public List<Customer> getListOfCustomers() {
        return listOfCustomers;
    }

    public List<ParkingLot> getListOfParkingLots() {
        return listOfParkingLots;
    }

    public PermitManager getPermitManager() {
        return permitManager;
    }

    public TransactionManager getTransactionManager() {
        return transactionManager;
    }
}
