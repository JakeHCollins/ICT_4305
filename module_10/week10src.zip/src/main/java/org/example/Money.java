package org.example;

public class Money {
    private final long cents;

    public Money(long cents) {
        this.cents = cents;
    }

    public Money(double dollars) {
        this.cents = Math.round(dollars * 100);
    }

    public long getCents() {
        return cents;
    }

    public double getDollars() {
        return cents / 100.0;
    }

    @Override
    public String toString() {
        return "$" + String.format("%.2f", getDollars());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Money money = (Money) obj;
        return cents == money.cents;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode((int) cents);
    }
}