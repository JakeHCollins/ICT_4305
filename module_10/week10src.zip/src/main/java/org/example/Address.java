package org.example;

import java.util.Objects;

public class Address {
    private final String streetAddress1;
    private final String streetAddress2;
    private final String city;
    private final String state;
    private final String zipCode;

    public Address(String streetAddress1, String streetAddress2, String city, String state, String zipCode) {
        this.streetAddress1 = streetAddress1;
        this.streetAddress2 = streetAddress2;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
    }

    public String getAddressInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append(streetAddress1);
        if (streetAddress2 != null && !streetAddress2.isEmpty()) {
            sb.append(", ").append(streetAddress2);
        }
        sb.append(", ").append(city).append(", ").append(state).append(" ").append(zipCode);
        return sb.toString();
    }

    public String getStreetAddress1() {
        return streetAddress1;
    }

    public String getStreetAddress2() {
        return streetAddress2;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZipCode() {
        return zipCode;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Address address = (Address) obj;
        return Objects.equals(streetAddress1, address.streetAddress1) &&
                Objects.equals(streetAddress2, address.streetAddress2) &&
                Objects.equals(city, address.city) &&
                Objects.equals(state, address.state) &&
                Objects.equals(zipCode, address.zipCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(streetAddress1, streetAddress2, city, state, zipCode);
    }
}