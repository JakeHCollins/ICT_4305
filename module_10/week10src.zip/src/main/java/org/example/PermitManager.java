package org.example;

import java.time.LocalDate;
import java.util.*;

public class PermitManager {
    private final Map<String, ParkingPermit> permits;

    public PermitManager() {
        this.permits = new HashMap<>();
    }

    public ParkingPermit register(Car vehicle) {
        LocalDate registrationDate = LocalDate.now();
        LocalDate expirationDate = registrationDate.plusYears(1);
        ParkingPermit permit = new ParkingPermit(vehicle, registrationDate, expirationDate);
        permits.put(permit.getId(), permit);
        return permit;
    }

    public ParkingPermit getPermit(String permitId) {
        return permits.get(permitId);
    }

    public List<ParkingPermit> getPermitsByCustomer(Customer customer) {
        List<ParkingPermit> customerPermits = new ArrayList<>();
        for (ParkingPermit permit : permits.values()) {
            if (permit.getVehicle().getOwner().equals(customer.getCustomerId())) {
                customerPermits.add(permit);
            }
        }
        return customerPermits;
    }

    public List<String> getAllPermitIds() {
        return new ArrayList<>(permits.keySet());
    }

    public Collection<ParkingPermit> getAllPermits() {
        return permits.values();
    }

    public boolean removePermit(String permitId) {
        return permits.remove(permitId) != null;
    }
}
