package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.Instant;
import static org.junit.jupiter.api.Assertions.*;

class ParkingChargeTest {

    private ParkingCharge compactCharge;
    private ParkingCharge suvCharge;
    private Instant testTime;
    private Money testAmount;

    @BeforeEach
    void setUp() {
        testTime = Instant.parse("2025-10-26T10:00:00Z");
        testAmount = new Money(1000);

        compactCharge = new ParkingCharge(
                "PERMIT-123",
                "LOT-A",
                testTime,
                testAmount,
                CarType.COMPACT
        );

        suvCharge = new ParkingCharge(
                "PERMIT-456",
                "LOT-B",
                testTime,
                testAmount,
                CarType.SUV
        );
    }

    @Test
    void testConstructor() {
        assertNotNull(compactCharge);
        assertEquals("PERMIT-123", compactCharge.getPermitId());
        assertEquals("LOT-A", compactCharge.getLotId());
        assertEquals(testTime, compactCharge.getIncurred());
    }

    @Test
    void testGetPermitId() {
        assertEquals("PERMIT-123", compactCharge.getPermitId());
        assertEquals("PERMIT-456", suvCharge.getPermitId());
    }

    @Test
    void testGetLotId() {
        assertEquals("LOT-A", compactCharge.getLotId());
        assertEquals("LOT-B", suvCharge.getLotId());
    }

    @Test
    void testGetIncurred() {
        assertEquals(testTime, compactCharge.getIncurred());
    }

    @Test
    void testGetAmountForCompactCar() {
        Money amount = compactCharge.getAmount();
        assertEquals(800, amount.getCents());
    }

    @Test
    void testGetAmountForSuvCar() {
        // SUV cars pay full price
        Money amount = suvCharge.getAmount();
        assertEquals(1000, amount.getCents());
    }

    @Test
    void testCompactCarDiscount() {
        Money originalAmount = new Money(2500);
        ParkingCharge charge = new ParkingCharge(
                "PERMIT-789",
                "LOT-C",
                testTime,
                originalAmount,
                CarType.COMPACT
        );

        Money discountedAmount = charge.getAmount();
        assertEquals(2000, discountedAmount.getCents());
    }

    @Test
    void testSuvNoDiscount() {
        Money originalAmount = new Money(2500);
        ParkingCharge charge = new ParkingCharge(
                "PERMIT-789",
                "LOT-C",
                testTime,
                originalAmount,
                CarType.SUV
        );

        Money fullAmount = charge.getAmount();
        assertEquals(2500, fullAmount.getCents());
    }

    @Test
    void testToString() {
        String result = compactCharge.toString();

        assertTrue(result.contains("permitId='PERMIT-123'"));
        assertTrue(result.contains("lotId='LOT-A'"));
        assertTrue(result.contains("incurred="));
        assertTrue(result.contains("amount="));
    }

    @Test
    void testGetAmountReturnsNewMoneyObject() {
        Money amount1 = compactCharge.getAmount();
        Money amount2 = compactCharge.getAmount();

        assertNotSame(amount1, amount2);
        assertEquals(amount1, amount2);
    }

    @Test
    void testSmallAmountCompactDiscount() {
        Money smallAmount = new Money(100); // $1.00
        ParkingCharge charge = new ParkingCharge(
                "PERMIT-999",
                "LOT-D",
                testTime,
                smallAmount,
                CarType.COMPACT
        );

        Money discountedAmount = charge.getAmount();
        assertEquals(80, discountedAmount.getCents());
    }
}