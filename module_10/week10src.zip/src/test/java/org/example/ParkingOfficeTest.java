package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class ParkingOfficeTest {

    private ParkingOffice parkingOffice;
    private Address officeAddress;

    @BeforeEach
    void setUp() {
        officeAddress = new Address(
                "500 Admin Blvd",
                "Floor 3",
                "Chicago",
                "IL",
                "60601"
        );
        parkingOffice = new ParkingOffice("Downtown Parking", officeAddress);
    }

    @Test
    void testConstructor() {
        assertNotNull(parkingOffice);
        assertEquals("Downtown Parking", parkingOffice.getParkingOfficeName());
        assertEquals(officeAddress, parkingOffice.getParkingOfficeAddress());
        assertNotNull(parkingOffice.getListOfCustomers());
        assertNotNull(parkingOffice.getListOfParkingLots());
        assertNotNull(parkingOffice.getPermitManager());
        assertNotNull(parkingOffice.getTransactionManager());
        assertTrue(parkingOffice.getListOfCustomers().isEmpty());
        assertTrue(parkingOffice.getListOfParkingLots().isEmpty());
    }

    @Test
    void testRegisterCustomer() {
        Address customerAddress = new Address(
                "123 Main St",
                null,
                "Springfield",
                "IL",
                "62701"
        );

        Customer customer = parkingOffice.register("John Doe", customerAddress, "555-1234");

        assertNotNull(customer);
        assertEquals("CUSTOMER-1", customer.getCustomerId());
        assertEquals("John Doe", customer.getName());
        assertEquals(customerAddress, customer.getAddress());
        assertEquals("555-1234", customer.getPhoneNumber());
        assertEquals(1, parkingOffice.getListOfCustomers().size());
        assertTrue(parkingOffice.getListOfCustomers().contains(customer));
    }

    @Test
    void testRegisterMultipleCustomers() {
        Address addr1 = new Address("123 St", null, "City1", "IL", "60601");
        Address addr2 = new Address("456 Ave", null, "City2", "IL", "60602");

        Customer customer1 = parkingOffice.register("Alice", addr1, "555-0001");
        Customer customer2 = parkingOffice.register("Bob", addr2, "555-0002");

        assertEquals("CUSTOMER-1", customer1.getCustomerId());
        assertEquals("CUSTOMER-2", customer2.getCustomerId());
        assertEquals(2, parkingOffice.getListOfCustomers().size());
    }

    @Test
    void testRegisterExistingCustomer() {
        Address addr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = new Customer("CUST-100", "Jane Doe", addr, "555-9999");
        
        parkingOffice.register(customer);
        assertEquals(1, parkingOffice.getListOfCustomers().size());
        
        parkingOffice.register(customer);
        assertEquals(1, parkingOffice.getListOfCustomers().size());
    }

    @Test
    void testRegisterCar() {
        Address customerAddress = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", customerAddress, "555-1234");

        Car car = new Car("ABC123", CarType.COMPACT, customer.getCustomerId());
        ParkingPermit permit = parkingOffice.register(car);

        assertNotNull(permit);
        assertNotNull(permit.getId());
        assertEquals(car, permit.getVehicle());
        assertNotNull(permit.getRegistrationDate());
        assertNotNull(permit.getExpirationDate());
        assertEquals(permit.getRegistrationDate().plusYears(1), permit.getExpirationDate());
    }

    @Test
    void testRegisterCarForCustomer() {
        Address customerAddress = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", customerAddress, "555-1234");

        ParkingPermit permit = parkingOffice.registerCar(customer, "ABC123", CarType.COMPACT);

        assertNotNull(permit);
        assertEquals("ABC123", permit.getVehicle().getLicense());
        assertEquals(CarType.COMPACT, permit.getVehicle().getType());
        assertEquals(customer.getCustomerId(), permit.getVehicle().getOwner());
        assertEquals(1, customer.getCars().size());
    }

    @Test
    void testRegisterMultipleCarsForCustomer() {
        Address customerAddress = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", customerAddress, "555-1234");

        ParkingPermit permit1 = parkingOffice.registerCar(customer, "ABC123", CarType.COMPACT);
        ParkingPermit permit2 = parkingOffice.registerCar(customer, "XYZ789", CarType.SUV);

        assertEquals(2, customer.getCars().size());
    }

    @Test
    void testParkVehicle() {
        Address customerAddr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", customerAddr, "555-1234");
        ParkingPermit permit = parkingOffice.registerCar(customer, "ABC123", CarType.COMPACT);

        Address lotAddr = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        ParkingLot lot = new ParkingLot("LOT-A", lotAddr, 100);
        parkingOffice.addLot(lot);

        LocalDate parkingDate = LocalDate.now();
        ParkingTransaction transaction = parkingOffice.park(parkingDate, permit, lot);

        assertNotNull(transaction);
        assertEquals(parkingDate, transaction.getTransactionDate());
        assertEquals(permit, transaction.getPermit());
        assertEquals(lot, transaction.getLot());
        assertNotNull(transaction.getFeeCharged());
    }

    @Test
    void testGetParkingChargesForPermit() {
        Address customerAddr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", customerAddr, "555-1234");
        ParkingPermit permit = parkingOffice.registerCar(customer, "ABC123", CarType.COMPACT);

        Address lotAddr = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        ParkingLot lot = new ParkingLot("LOT-A", lotAddr, 100);
        parkingOffice.addLot(lot);

        parkingOffice.park(LocalDate.now(), permit, lot);
        parkingOffice.park(LocalDate.now(), permit, lot);

        Money charges = parkingOffice.getParkingCharges(permit);
        assertNotNull(charges);
        assertEquals(1600, charges.getCents());
    }

    @Test
    void testGetParkingChargesForCustomer() {
        Address customerAddr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", customerAddr, "555-1234");
        
        ParkingPermit permit1 = parkingOffice.registerCar(customer, "ABC123", CarType.COMPACT);
        ParkingPermit permit2 = parkingOffice.registerCar(customer, "XYZ789", CarType.SUV);

        Address lotAddr = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        ParkingLot lot = new ParkingLot("LOT-A", lotAddr, 100);
        parkingOffice.addLot(lot);

        parkingOffice.park(LocalDate.now(), permit1, lot);
        parkingOffice.park(LocalDate.now(), permit2, lot);

        Money charges = parkingOffice.getParkingCharges(customer);
        assertNotNull(charges);
        assertEquals(1800, charges.getCents());
    }

    @Test
    void testAddLot() {
        Address lotAddress = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        ParkingLot lot = new ParkingLot("LOT-A", lotAddress, 100);

        parkingOffice.addLot(lot);

        assertEquals(1, parkingOffice.getListOfParkingLots().size());
        assertTrue(parkingOffice.getListOfParkingLots().contains(lot));
    }

    @Test
    void testAddMultipleLots() {
        Address addr1 = new Address("100 Way", null, "City", "IL", "60601");
        Address addr2 = new Address("200 Ave", null, "City", "IL", "60602");

        ParkingLot lot1 = new ParkingLot("LOT-A", addr1, 100);
        ParkingLot lot2 = new ParkingLot("LOT-B", addr2, 150);

        parkingOffice.addLot(lot1);
        parkingOffice.addLot(lot2);

        assertEquals(2, parkingOffice.getListOfParkingLots().size());
    }

    @Test
    void testGetCustomerByName() {
        Address addr = new Address("123 St", null, "City", "IL", "60601");
        parkingOffice.register("John Doe", addr, "555-1234");
        parkingOffice.register("Jane Smith", addr, "555-5678");

        Customer found = parkingOffice.getCustomer("John Doe");
        assertNotNull(found);
        assertEquals("John Doe", found.getName());
        assertEquals("CUSTOMER-1", found.getCustomerId());
    }

    @Test
    void testGetCustomerNotFound() {
        Customer notFound = parkingOffice.getCustomer("Nonexistent Customer");
        assertNull(notFound);
    }

    @Test
    void testGetCustomerWithMultipleCustomers() {
        Address addr = new Address("123 St", null, "City", "IL", "60601");
        parkingOffice.register("Alice", addr, "555-0001");
        parkingOffice.register("Bob", addr, "555-0002");
        parkingOffice.register("Charlie", addr, "555-0003");

        Customer found = parkingOffice.getCustomer("Bob");
        assertNotNull(found);
        assertEquals("Bob", found.getName());
        assertEquals("CUSTOMER-2", found.getCustomerId());
    }

    @Test
    void testGetCustomerIds() {
        assertTrue(parkingOffice.getCustomerIds().isEmpty());

        Address addr1 = new Address("123 St", null, "City", "IL", "60601");
        Address addr2 = new Address("456 Ave", null, "City", "IL", "60602");

        Customer customer1 = parkingOffice.register("Alice", addr1, "555-0001");
        Customer customer2 = parkingOffice.register("Bob", addr2, "555-0002");

        var customerIds = parkingOffice.getCustomerIds();
        assertEquals(2, customerIds.size());
        assertTrue(customerIds.contains("CUSTOMER-1"));
        assertTrue(customerIds.contains("CUSTOMER-2"));
    }

    @Test
    void testGetPermitIds() {
        assertTrue(parkingOffice.getPermitIds().isEmpty());

        Address addr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", addr, "555-1234");

        ParkingPermit permit1 = parkingOffice.registerCar(customer, "ABC123", CarType.COMPACT);
        ParkingPermit permit2 = parkingOffice.registerCar(customer, "XYZ789", CarType.SUV);

        var permitIds = parkingOffice.getPermitIds();
        assertEquals(2, permitIds.size());
        assertTrue(permitIds.contains(permit1.getId()));
        assertTrue(permitIds.contains(permit2.getId()));
    }

    @Test
    void testGetPermitIdsMultipleCustomers() {
        Address addr1 = new Address("123 St", null, "City", "IL", "60601");
        Address addr2 = new Address("456 Ave", null, "City", "IL", "60602");

        Customer customer1 = parkingOffice.register("Alice", addr1, "555-0001");
        Customer customer2 = parkingOffice.register("Bob", addr2, "555-0002");

        ParkingPermit permit1 = parkingOffice.registerCar(customer1, "ABC123", CarType.COMPACT);
        ParkingPermit permit2 = parkingOffice.registerCar(customer1, "DEF456", CarType.SUV);
        ParkingPermit permit3 = parkingOffice.registerCar(customer2, "GHI789", CarType.COMPACT);

        var permitIds = parkingOffice.getPermitIds();
        assertEquals(3, permitIds.size());
        assertTrue(permitIds.contains(permit1.getId()));
        assertTrue(permitIds.contains(permit2.getId()));
        assertTrue(permitIds.contains(permit3.getId()));
    }

    @Test
    void testGetPermitIdsForSpecificCustomer() {
        Address addr1 = new Address("123 St", null, "City", "IL", "60601");
        Address addr2 = new Address("456 Ave", null, "City", "IL", "60602");

        Customer customer1 = parkingOffice.register("Alice", addr1, "555-0001");
        Customer customer2 = parkingOffice.register("Bob", addr2, "555-0002");

        ParkingPermit permit1 = parkingOffice.registerCar(customer1, "ABC123", CarType.COMPACT);
        ParkingPermit permit2 = parkingOffice.registerCar(customer1, "DEF456", CarType.SUV);
        ParkingPermit permit3 = parkingOffice.registerCar(customer2, "GHI789", CarType.COMPACT);

        var customer1PermitIds = parkingOffice.getPermitIds(customer1);
        assertEquals(2, customer1PermitIds.size());
        assertTrue(customer1PermitIds.contains(permit1.getId()));
        assertTrue(customer1PermitIds.contains(permit2.getId()));
        assertFalse(customer1PermitIds.contains(permit3.getId()));

        var customer2PermitIds = parkingOffice.getPermitIds(customer2);
        assertEquals(1, customer2PermitIds.size());
        assertTrue(customer2PermitIds.contains(permit3.getId()));
        assertFalse(customer2PermitIds.contains(permit1.getId()));
        assertFalse(customer2PermitIds.contains(permit2.getId()));
    }

    @Test
    void testGetPermitIdsForCustomerWithNoCars() {
        Address addr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", addr, "555-1234");

        var permitIds = parkingOffice.getPermitIds(customer);
        assertTrue(permitIds.isEmpty());
    }

    @Test
    void testGetPermitIdsForNullCustomer() {
        var permitIds = parkingOffice.getPermitIds(null);
        assertNotNull(permitIds);
        assertTrue(permitIds.isEmpty());
    }

    @Test
    void testCompleteWorkflow() {
        Address customerAddr = new Address("123 Main St", null, "Springfield", "IL", "62701");
        Customer customer = parkingOffice.register("John Doe", customerAddr, "555-1234");

        ParkingPermit permit = parkingOffice.registerCar(customer, "ABC123", CarType.COMPACT);

        Address lotAddr = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        ParkingLot lot = new ParkingLot("LOT-A", lotAddr, 100);
        parkingOffice.addLot(lot);

        ParkingTransaction transaction = parkingOffice.park(LocalDate.now(), permit, lot);

        assertEquals(1, parkingOffice.getListOfCustomers().size());
        assertEquals(1, parkingOffice.getListOfParkingLots().size());
        assertNotNull(transaction);
        assertEquals(800, transaction.getFeeCharged().getCents());
    }
}
