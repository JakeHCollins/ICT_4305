package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class ParkingPermitTest {

    private Car testCar;
    private ParkingPermit permit;
    private LocalDate registrationDate;
    private LocalDate expirationDate;

    @BeforeEach
    void setUp() {
        testCar = new Car("ABC123", CarType.COMPACT, "CUSTOMER-1");
        registrationDate = LocalDate.of(2025, 1, 1);
        expirationDate = LocalDate.of(2026, 1, 1);
        permit = new ParkingPermit(testCar, registrationDate, expirationDate);
    }

    @Test
    void testConstructor() {
        assertNotNull(permit);
        assertNotNull(permit.getId());
        assertEquals(testCar, permit.getVehicle());
        assertEquals(registrationDate, permit.getRegistrationDate());
        assertEquals(expirationDate, permit.getExpirationDate());
    }

    @Test
    void testGetId() {
        String id = permit.getId();
        assertNotNull(id);
        assertFalse(id.isEmpty());
    }

    @Test
    void testUniqueIds() {
        ParkingPermit permit2 = new ParkingPermit(testCar, registrationDate, expirationDate);
        assertNotEquals(permit.getId(), permit2.getId());
    }

    @Test
    void testGetVehicle() {
        assertEquals(testCar, permit.getVehicle());
        assertEquals("ABC123", permit.getVehicle().getLicense());
    }

    @Test
    void testGetRegistrationDate() {
        assertEquals(registrationDate, permit.getRegistrationDate());
    }

    @Test
    void testGetExpirationDate() {
        assertEquals(expirationDate, permit.getExpirationDate());
    }

    @Test
    void testIsExpiredBeforeExpiration() {
        LocalDate beforeExpiration = LocalDate.of(2025, 12, 31);
        assertFalse(permit.isExpired(beforeExpiration));
    }

    @Test
    void testIsExpiredOnExpirationDate() {
        assertFalse(permit.isExpired(expirationDate));
    }

    @Test
    void testIsExpiredAfterExpiration() {
        LocalDate afterExpiration = LocalDate.of(2026, 1, 2);
        assertTrue(permit.isExpired(afterExpiration));
    }

    @Test
    void testToString() {
        String result = permit.toString();
        assertTrue(result.contains("ParkingPermit"));
        assertTrue(result.contains("id="));
        assertTrue(result.contains("ABC123"));
        assertTrue(result.contains("registrationDate="));
        assertTrue(result.contains("expirationDate="));
    }

    @Test
    void testEquals() {
        ParkingPermit samePermit = permit;
        assertEquals(permit, samePermit);
    }

    @Test
    void testNotEquals() {
        ParkingPermit differentPermit = new ParkingPermit(testCar, registrationDate, expirationDate);
        assertNotEquals(permit, differentPermit);
    }

    @Test
    void testHashCode() {
        int hash1 = permit.hashCode();
        int hash2 = permit.hashCode();
        assertEquals(hash1, hash2);
    }
}
