package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class CarTest {

    private Car compactCar;
    private Car suvCar;

    @BeforeEach
    void setUp() {
        compactCar = new Car("ABC123", CarType.COMPACT, "CUSTOMER-1");
        suvCar = new Car("XYZ789", CarType.SUV, "CUSTOMER-2");
    }

    @Test
    void testConstructor() {
        assertNotNull(compactCar);
        assertEquals("ABC123", compactCar.getLicense());
        assertEquals(CarType.COMPACT, compactCar.getType());
        assertEquals("CUSTOMER-1", compactCar.getOwner());
        assertNull(compactCar.getPermit());
        assertNull(compactCar.getPermitExpiration());
    }

    @Test
    void testSetAndGetPermit() {
        String permit = "PERMIT-12345";
        compactCar.setPermit(permit);
        assertEquals(permit, compactCar.getPermit());
    }

    @Test
    void testSetAndGetPermitExpiration() {
        LocalDate expiration = LocalDate.of(2026, 12, 31);
        compactCar.setPermitExpiration(expiration);
        assertEquals(expiration, compactCar.getPermitExpiration());
    }

    @Test
    void testGetLicense() {
        assertEquals("ABC123", compactCar.getLicense());
        assertEquals("XYZ789", suvCar.getLicense());
    }

    @Test
    void testGetType() {
        assertEquals(CarType.COMPACT, compactCar.getType());
        assertEquals(CarType.SUV, suvCar.getType());
    }

    @Test
    void testGetOwner() {
        assertEquals("CUSTOMER-1", compactCar.getOwner());
        assertEquals("CUSTOMER-2", suvCar.getOwner());
    }

    @Test
    void testToString() {
        compactCar.setPermit("PERMIT-12345");
        compactCar.setPermitExpiration(LocalDate.of(2026, 1, 1));

        String result = compactCar.toString();

        assertTrue(result.contains("permit='PERMIT-12345'"));
        assertTrue(result.contains("license='ABC123'"));
        assertTrue(result.contains("type=COMPACT"));
        assertTrue(result.contains("owner='CUSTOMER-1'"));
        assertTrue(result.contains("permitExpiration=2026-01-01"));
    }

    @Test
    void testToStringWithNullPermit() {
        String result = compactCar.toString();

        assertTrue(result.contains("permit='null'"));
        assertTrue(result.contains("permitExpiration=null"));
    }
}