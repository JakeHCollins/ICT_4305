package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

class AddressTest {

    private Address address;
    private Address addressWithoutStreet2;

    @BeforeEach
    void setUp() {
        address = new Address(
                "123 Main St",
                "Apt 4B",
                "Springfield",
                "IL",
                "62701"
        );

        addressWithoutStreet2 = new Address(
                "456 Oak Ave",
                null,
                "Chicago",
                "IL",
                "60601"
        );
    }

    @Test
    void testConstructor() {
        assertNotNull(address);
        assertEquals("123 Main St", address.getStreetAddress1());
        assertEquals("Apt 4B", address.getStreetAddress2());
        assertEquals("Springfield", address.getCity());
        assertEquals("IL", address.getState());
        assertEquals("62701", address.getZipCode());
    }

    @Test
    void testGetAddressInfoWithStreetAddress2() {
        String expected = "123 Main St, Apt 4B, Springfield, IL 62701";
        assertEquals(expected, address.getAddressInfo());
    }

    @Test
    void testGetAddressInfoWithoutStreetAddress2() {
        String expected = "456 Oak Ave, Chicago, IL 60601";
        assertEquals(expected, addressWithoutStreet2.getAddressInfo());
    }

    @Test
    void testGetAddressInfoWithEmptyStreetAddress2() {
        Address addressWithEmptyStreet2 = new Address(
                "789 Pine Rd",
                "",
                "Peoria",
                "IL",
                "61602"
        );
        String expected = "789 Pine Rd, Peoria, IL 61602";
        assertEquals(expected, addressWithEmptyStreet2.getAddressInfo());
    }

    @Test
    void testGetStreetAddress1() {
        assertEquals("123 Main St", address.getStreetAddress1());
    }

    @Test
    void testGetStreetAddress2() {
        assertEquals("Apt 4B", address.getStreetAddress2());
        assertNull(addressWithoutStreet2.getStreetAddress2());
    }

    @Test
    void testGetCity() {
        assertEquals("Springfield", address.getCity());
    }

    @Test
    void testGetState() {
        assertEquals("IL", address.getState());
    }

    @Test
    void testGetZipCode() {
        assertEquals("62701", address.getZipCode());
    }
}