package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class PermitManagerTest {

    private PermitManager permitManager;
    private Car testCar;
    private Customer testCustomer;

    @BeforeEach
    void setUp() {
        permitManager = new PermitManager();
        Address address = new Address("123 Main St", null, "City", "IL", "60601");
        testCustomer = new Customer("CUSTOMER-1", "John Doe", address, "555-1234");
        testCar = new Car("ABC123", CarType.COMPACT, testCustomer.getCustomerId());
    }

    @Test
    void testRegister() {
        ParkingPermit permit = permitManager.register(testCar);

        assertNotNull(permit);
        assertNotNull(permit.getId());
        assertEquals(testCar, permit.getVehicle());
        assertNotNull(permit.getRegistrationDate());
        assertNotNull(permit.getExpirationDate());
    }

    @Test
    void testRegisterSetsExpirationOneYearLater() {
        ParkingPermit permit = permitManager.register(testCar);

        LocalDate expectedExpiration = permit.getRegistrationDate().plusYears(1);
        assertEquals(expectedExpiration, permit.getExpirationDate());
    }

    @Test
    void testGetPermit() {
        ParkingPermit permit = permitManager.register(testCar);
        
        ParkingPermit retrieved = permitManager.getPermit(permit.getId());
        assertNotNull(retrieved);
        assertEquals(permit, retrieved);
    }

    @Test
    void testGetPermitNotFound() {
        ParkingPermit notFound = permitManager.getPermit("INVALID-ID");
        assertNull(notFound);
    }

    @Test
    void testGetPermitsByCustomer() {
        Car car1 = new Car("ABC123", CarType.COMPACT, testCustomer.getCustomerId());
        Car car2 = new Car("XYZ789", CarType.SUV, testCustomer.getCustomerId());

        ParkingPermit permit1 = permitManager.register(car1);
        ParkingPermit permit2 = permitManager.register(car2);

        var customerPermits = permitManager.getPermitsByCustomer(testCustomer);
        assertEquals(2, customerPermits.size());
        assertTrue(customerPermits.contains(permit1));
        assertTrue(customerPermits.contains(permit2));
    }

    @Test
    void testGetPermitsByCustomerWithNoPermits() {
        var customerPermits = permitManager.getPermitsByCustomer(testCustomer);
        assertTrue(customerPermits.isEmpty());
    }

    @Test
    void testGetAllPermitIds() {
        assertTrue(permitManager.getAllPermitIds().isEmpty());

        ParkingPermit permit1 = permitManager.register(testCar);
        Car car2 = new Car("XYZ789", CarType.SUV, testCustomer.getCustomerId());
        ParkingPermit permit2 = permitManager.register(car2);

        var permitIds = permitManager.getAllPermitIds();
        assertEquals(2, permitIds.size());
        assertTrue(permitIds.contains(permit1.getId()));
        assertTrue(permitIds.contains(permit2.getId()));
    }

    @Test
    void testGetAllPermits() {
        assertTrue(permitManager.getAllPermits().isEmpty());

        ParkingPermit permit1 = permitManager.register(testCar);
        Car car2 = new Car("XYZ789", CarType.SUV, testCustomer.getCustomerId());
        ParkingPermit permit2 = permitManager.register(car2);

        var permits = permitManager.getAllPermits();
        assertEquals(2, permits.size());
        assertTrue(permits.contains(permit1));
        assertTrue(permits.contains(permit2));
    }

    @Test
    void testRemovePermit() {
        ParkingPermit permit = permitManager.register(testCar);
        assertEquals(1, permitManager.getAllPermitIds().size());

        boolean removed = permitManager.removePermit(permit.getId());
        assertTrue(removed);
        assertEquals(0, permitManager.getAllPermitIds().size());
    }

    @Test
    void testRemoveNonexistentPermit() {
        boolean removed = permitManager.removePermit("INVALID-ID");
        assertFalse(removed);
    }

    @Test
    void testMultipleCustomersPermits() {
        Address address2 = new Address("456 Oak Ave", null, "City", "IL", "60602");
        Customer customer2 = new Customer("CUSTOMER-2", "Jane Smith", address2, "555-5678");

        Car car1 = new Car("ABC123", CarType.COMPACT, testCustomer.getCustomerId());
        Car car2 = new Car("DEF456", CarType.SUV, testCustomer.getCustomerId());
        Car car3 = new Car("GHI789", CarType.COMPACT, customer2.getCustomerId());

        permitManager.register(car1);
        permitManager.register(car2);
        permitManager.register(car3);

        var customer1Permits = permitManager.getPermitsByCustomer(testCustomer);
        var customer2Permits = permitManager.getPermitsByCustomer(customer2);

        assertEquals(2, customer1Permits.size());
        assertEquals(1, customer2Permits.size());
        assertEquals(3, permitManager.getAllPermitIds().size());
    }
}
