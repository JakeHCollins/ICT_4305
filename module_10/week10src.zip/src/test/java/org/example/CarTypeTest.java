package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CarTypeTest {

    @Test
    void testEnumValues() {
        CarType[] values = CarType.values();
        assertEquals(2, values.length);
        assertEquals(CarType.COMPACT, values[0]);
        assertEquals(CarType.SUV, values[1]);
    }

    @Test
    void testCompactExists() {
        assertNotNull(CarType.COMPACT);
        assertEquals("COMPACT", CarType.COMPACT.name());
    }

    @Test
    void testSuvExists() {
        assertNotNull(CarType.SUV);
        assertEquals("SUV", CarType.SUV.name());
    }

    @Test
    void testValueOf() {
        assertEquals(CarType.COMPACT, CarType.valueOf("COMPACT"));
        assertEquals(CarType.SUV, CarType.valueOf("SUV"));
    }

    @Test
    void testValueOfInvalidThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            CarType.valueOf("INVALID");
        });
    }

    @Test
    void testEnumEquality() {
        CarType compact1 = CarType.COMPACT;
        CarType compact2 = CarType.COMPACT;
        assertSame(compact1, compact2);
        assertEquals(compact1, compact2);
    }

    @Test
    void testEnumInequality() {
        assertNotEquals(CarType.COMPACT, CarType.SUV);
    }
}