package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class ParkingTransactionTest {

    private ParkingTransaction transaction;
    private ParkingPermit permit;
    private ParkingLot lot;
    private LocalDate transactionDate;

    @BeforeEach
    void setUp() {
        transactionDate = LocalDate.of(2025, 11, 16);
        
        Car car = new Car("ABC123", CarType.COMPACT, "CUSTOMER-1");
        LocalDate registrationDate = LocalDate.of(2025, 1, 1);
        LocalDate expirationDate = LocalDate.of(2026, 1, 1);
        permit = new ParkingPermit(car, registrationDate, expirationDate);
        
        Address lotAddress = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        lot = new ParkingLot("LOT-A", lotAddress, 100);
        
        transaction = new ParkingTransaction(transactionDate, permit, lot);
    }

    @Test
    void testConstructor() {
        assertNotNull(transaction);
        assertEquals(transactionDate, transaction.getTransactionDate());
        assertEquals(permit, transaction.getPermit());
        assertEquals(lot, transaction.getLot());
        assertNotNull(transaction.getFeeCharged());
    }

    @Test
    void testGetTransactionDate() {
        assertEquals(transactionDate, transaction.getTransactionDate());
    }

    @Test
    void testGetPermit() {
        assertEquals(permit, transaction.getPermit());
    }

    @Test
    void testGetLot() {
        assertEquals(lot, transaction.getLot());
    }

    @Test
    void testGetFeeChargedForCompactCar() {
        Money fee = transaction.getFeeCharged();
        assertEquals(800, fee.getCents());
        assertEquals(8.00, fee.getDollars(), 0.01);
    }

    @Test
    void testGetFeeChargedForSuvCar() {
        Car suvCar = new Car("XYZ789", CarType.SUV, "CUSTOMER-2");
        LocalDate registrationDate = LocalDate.of(2025, 1, 1);
        LocalDate expirationDate = LocalDate.of(2026, 1, 1);
        ParkingPermit suvPermit = new ParkingPermit(suvCar, registrationDate, expirationDate);
        
        ParkingTransaction suvTransaction = new ParkingTransaction(transactionDate, suvPermit, lot);
        
        Money fee = suvTransaction.getFeeCharged();
        assertEquals(1000, fee.getCents());
        assertEquals(10.00, fee.getDollars(), 0.01);
    }

    @Test
    void testToString() {
        String result = transaction.toString();
        assertTrue(result.contains("ParkingTransaction"));
        assertTrue(result.contains("transactionDate="));
        assertTrue(result.contains("permit="));
        assertTrue(result.contains("lot="));
        assertTrue(result.contains("feeCharged="));
    }

    @Test
    void testEquals() {
        ParkingTransaction sameTransaction = transaction;
        assertEquals(transaction, sameTransaction);
    }

    @Test
    void testNotEquals() {
        LocalDate differentDate = LocalDate.of(2025, 11, 17);
        ParkingTransaction differentTransaction = new ParkingTransaction(differentDate, permit, lot);
        assertNotEquals(transaction, differentTransaction);
    }

    @Test
    void testHashCode() {
        int hash1 = transaction.hashCode();
        int hash2 = transaction.hashCode();
        assertEquals(hash1, hash2);
    }

    @Test
    void testMultipleTransactionsSamePermit() {
        ParkingTransaction transaction2 = new ParkingTransaction(transactionDate, permit, lot);
        
        assertEquals(transaction, transaction2);
    }
}
