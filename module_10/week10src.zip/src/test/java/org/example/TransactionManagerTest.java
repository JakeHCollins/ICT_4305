package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class TransactionManagerTest {

    private TransactionManager transactionManager;
    private PermitManager permitManager;
    private ParkingPermit permit;
    private ParkingLot lot;
    private Customer customer;

    @BeforeEach
    void setUp() {
        transactionManager = new TransactionManager();
        permitManager = new PermitManager();
        
        Address address = new Address("123 Main St", null, "City", "IL", "60601");
        customer = new Customer("CUSTOMER-1", "John Doe", address, "555-1234");
        
        Car car = new Car("ABC123", CarType.COMPACT, customer.getCustomerId());
        permit = permitManager.register(car);
        
        Address lotAddress = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        lot = new ParkingLot("LOT-A", lotAddress, 100);
    }

    @Test
    void testPark() {
        LocalDate parkingDate = LocalDate.now();
        ParkingTransaction transaction = transactionManager.park(parkingDate, permit, lot);

        assertNotNull(transaction);
        assertEquals(parkingDate, transaction.getTransactionDate());
        assertEquals(permit, transaction.getPermit());
        assertEquals(lot, transaction.getLot());
    }

    @Test
    void testGetAllTransactions() {
        assertTrue(transactionManager.getAllTransactions().isEmpty());

        transactionManager.park(LocalDate.now(), permit, lot);
        assertEquals(1, transactionManager.getAllTransactions().size());

        transactionManager.park(LocalDate.now(), permit, lot);
        assertEquals(2, transactionManager.getAllTransactions().size());
    }

    @Test
    void testGetParkingChargesByPermit() {
        Money initialCharges = transactionManager.getParkingCharges(permit);
        assertEquals(0, initialCharges.getCents());

        transactionManager.park(LocalDate.now(), permit, lot);
        Money charges = transactionManager.getParkingCharges(permit);
        assertEquals(800, charges.getCents());

        transactionManager.park(LocalDate.now(), permit, lot);
        charges = transactionManager.getParkingCharges(permit);
        assertEquals(1600, charges.getCents());
    }

    @Test
    void testGetParkingChargesByPermitId() {
        transactionManager.park(LocalDate.now(), permit, lot);
        Money charges = transactionManager.getParkingCharges(permit.getId());
        assertEquals(800, charges.getCents());
    }

    @Test
    void testGetParkingChargesByCustomer() {
        Car car1 = new Car("ABC123", CarType.COMPACT, customer.getCustomerId());
        Car car2 = new Car("XYZ789", CarType.SUV, customer.getCustomerId());
        
        ParkingPermit permit1 = permitManager.register(car1);
        ParkingPermit permit2 = permitManager.register(car2);

        transactionManager.park(LocalDate.now(), permit1, lot);
        transactionManager.park(LocalDate.now(), permit2, lot);

        Money totalCharges = transactionManager.getParkingCharges(customer, permitManager);
        assertEquals(1800, totalCharges.getCents());
    }

    @Test
    void testGetParkingChargesForCustomerWithNoTransactions() {
        Money charges = transactionManager.getParkingCharges(customer, permitManager);
        assertEquals(0, charges.getCents());
    }

    @Test
    void testGetTransactionsByPermit() {
        assertTrue(transactionManager.getTransactions(permit).isEmpty());

        ParkingTransaction t1 = transactionManager.park(LocalDate.now(), permit, lot);
        ParkingTransaction t2 = transactionManager.park(LocalDate.now(), permit, lot);

        var transactions = transactionManager.getTransactions(permit);
        assertEquals(2, transactions.size());
        assertTrue(transactions.contains(t1));
        assertTrue(transactions.contains(t2));
    }

    @Test
    void testGetTransactionsByLot() {
        Address lot2Address = new Address("200 Parking Way", null, "Chicago", "IL", "60602");
        ParkingLot lot2 = new ParkingLot("LOT-B", lot2Address, 50);

        transactionManager.park(LocalDate.now(), permit, lot);
        transactionManager.park(LocalDate.now(), permit, lot);
        transactionManager.park(LocalDate.now(), permit, lot2);

        var lot1Transactions = transactionManager.getTransactionsByLot(lot);
        var lot2Transactions = transactionManager.getTransactionsByLot(lot2);

        assertEquals(2, lot1Transactions.size());
        assertEquals(1, lot2Transactions.size());
    }

    @Test
    void testMultiplePermitsSeparateCharges() {
        Car car2 = new Car("XYZ789", CarType.SUV, customer.getCustomerId());
        ParkingPermit permit2 = permitManager.register(car2);

        transactionManager.park(LocalDate.now(), permit, lot);
        transactionManager.park(LocalDate.now(), permit2, lot);

        Money charges1 = transactionManager.getParkingCharges(permit);
        Money charges2 = transactionManager.getParkingCharges(permit2);

        assertEquals(800, charges1.getCents()); // Compact
        assertEquals(1000, charges2.getCents()); // SUV
    }

    @Test
    void testParkingChargesAccumulation() {
        for (int i = 0; i < 5; i++) {
            transactionManager.park(LocalDate.now(), permit, lot);
        }

        Money totalCharges = transactionManager.getParkingCharges(permit);
        assertEquals(4000, totalCharges.getCents()); // 5 * $8.00
    }
}
