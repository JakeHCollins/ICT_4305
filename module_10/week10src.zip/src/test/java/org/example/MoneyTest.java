package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MoneyTest {

    @Test
    void testConstructorWithCents() {
        Money money = new Money(100);
        assertEquals(100, money.getCents());
        assertEquals(1.00, money.getDollars(), 0.001);
    }

    @Test
    void testConstructorWithDollars() {
        Money money = new Money(10.50);
        assertEquals(1050, money.getCents());
        assertEquals(10.50, money.getDollars(), 0.001);
    }

    @Test
    void testConstructorWithDollarsRounding() {
        Money money = new Money(10.555);
        assertEquals(1056, money.getCents());
    }

    @Test
    void testGetCents() {
        Money money = new Money(250);
        assertEquals(250, money.getCents());
    }

    @Test
    void testGetDollars() {
        Money money = new Money(1550);
        assertEquals(15.50, money.getDollars(), 0.001);
    }

    @Test
    void testGetDollarsFromDollarConstructor() {
        Money money = new Money(25.75);
        assertEquals(25.75, money.getDollars(), 0.001);
    }

    @Test
    void testToString() {
        Money money1 = new Money(1050);
        assertEquals("$10.50", money1.toString());

        Money money2 = new Money(5);
        assertEquals("$0.05", money2.toString());

        Money money3 = new Money(100);
        assertEquals("$1.00", money3.toString());
    }

    @Test
    void testToStringWithLargeAmount() {
        Money money = new Money(123456);
        assertEquals("$1234.56", money.toString());
    }

    @Test
    void testToStringWithZero() {
        Money money = new Money(0);
        assertEquals("$0.00", money.toString());
    }

    @Test
    void testEquals() {
        Money money1 = new Money(1000);
        Money money2 = new Money(1000);
        Money money3 = new Money(2000);

        assertEquals(money1, money2);
        assertNotEquals(money1, money3);
    }

    @Test
    void testEqualsSameObject() {
        Money money = new Money(1000);
        assertEquals(money, money);
    }

    @Test
    void testEqualsWithNull() {
        Money money = new Money(1000);
        assertNotEquals(money, null);
    }

    @Test
    void testEqualsWithDifferentClass() {
        Money money = new Money(1000);
        assertNotEquals(money, "1000");
    }

    @Test
    void testEqualsFromDifferentConstructors() {
        Money money1 = new Money(1050);
        Money money2 = new Money(10.50);
        assertEquals(money1, money2);
    }

    @Test
    void testHashCode() {
        Money money1 = new Money(1000);
        Money money2 = new Money(1000);
        Money money3 = new Money(2000);

        assertEquals(money1.hashCode(), money2.hashCode());
        assertNotEquals(money1.hashCode(), money3.hashCode());
    }

    @Test
    void testHashCodeConsistency() {
        Money money = new Money(1000);
        int hash1 = money.hashCode();
        int hash2 = money.hashCode();
        assertEquals(hash1, hash2);
    }

    @Test
    void testNegativeAmount() {
        Money money = new Money(-500);
        assertEquals(-500, money.getCents());
        assertEquals(-5.00, money.getDollars(), 0.001);
    }
}