package org.example;

import java.util.Objects;

public class ParkingLot {
    private String lotId;
    private Address address;
    private int capacity;

    public ParkingLot(String lotId, Address address, int capacity) {
        this.lotId = lotId;
        this.address = address;
        this.capacity = capacity;
    }

    public void entry(Car car) {
        System.out.println("Car " + car.getLicense() + " entered parking lot " + lotId);
    }

    public String getLotId() {
        return lotId;
    }

    public Address getAddress() {
        return address;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        return "ParkingLot{" +
                "lotId='" + lotId + '\'' +
                ", address=" + address.getAddressInfo() +
                ", capacity=" + capacity +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ParkingLot that = (ParkingLot) obj;
        return Objects.equals(lotId, that.lotId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lotId);
    }
}