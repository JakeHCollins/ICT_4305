package org.example;

public enum CarType {
    COMPACT,
    SUV
}