package org.example;

import java.util.ArrayList;
import java.util.List;

public class ParkingOffice {
    private String name;
    private Address address;
    private List<Customer> customers;
    private List<Car> cars;
    private List<ParkingLot> lots;
    private List<ParkingCharge> charges;

    public ParkingOffice(String name, Address address) {
        this.name = name;
        this.address = address;
        this.customers = new ArrayList<>();
        this.cars = new ArrayList<>();
        this.lots = new ArrayList<>();
        this.charges = new ArrayList<>();
    }

    public Customer register(String name, Address address, String phone) {
        String customerId = "CUSTOMER-" + (customers.size() + 1);
        Customer customer = new Customer(customerId, name, address, phone);
        customers.add(customer);
        return customer;
    }

    public Car register(Customer c, String license, CarType t) {
        Car car = c.register(license, t);
        cars.add(car);
        return car;
    }

    public Customer getCustomer(String name) {
        for (Customer customer : customers) {
            if (customer.getName().equals(name)) {
                return customer;
            }
        }
        return null;
    }

    public Money addCharge(ParkingCharge charge) {
        charges.add(charge);
        return charge.getAmount();
    }

    public void addLot(ParkingLot lot) {
        lots.add(lot);
    }

    public List<String> getCustomerIds() {
        List<String> customerIds = new ArrayList<>();
        for (Customer customer : customers) {
            customerIds.add(customer.getCustomerId());
        }
        return customerIds;
    }

    public List<String> getPermitIds() {
        List<String> permitIds = new ArrayList<>();
        for (Car car : cars) {
            if (car.getPermit() != null) {
                permitIds.add(car.getPermit());
            }
        }
        return permitIds;
    }

    public List<String> getPermitIds(Customer customer) {
        List<String> permitIds = new ArrayList<>();
        if (customer != null) {
            for (Car car : customer.getCars()) {
                if (car.getPermit() != null) {
                    permitIds.add(car.getPermit());
                }
            }
        }
        return permitIds;
    }

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return address;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public List<Car> getCars() {
        return cars;
    }

    public List<ParkingLot> getLots() {
        return lots;
    }

    public List<ParkingCharge> getCharges() {
        return charges;
    }
}