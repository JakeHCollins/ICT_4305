package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    private Customer customer;
    private Address address;

    @BeforeEach
    void setUp() {
        address = new Address(
                "123 Main St",
                "Apt 4B",
                "Springfield",
                "IL",
                "62701"
        );
        customer = new Customer("CUSTOMER-1", "John Doe", address, "555-1234");
    }

    @Test
    void testConstructor() {
        assertNotNull(customer);
        assertEquals("CUSTOMER-1", customer.getCustomerId());
        assertEquals("John Doe", customer.getName());
        assertEquals(address, customer.getAddress());
        assertEquals("555-1234", customer.getPhoneNumber());
        assertNotNull(customer.getCars());
        assertTrue(customer.getCars().isEmpty());
    }

    @Test
    void testRegisterCar() {
        Car car = customer.register("ABC123", CarType.COMPACT);

        assertNotNull(car);
        assertEquals("ABC123", car.getLicense());
        assertEquals(CarType.COMPACT, car.getType());
        assertEquals("CUSTOMER-1", car.getOwner());
        assertNotNull(car.getPermit());
        assertNotNull(car.getPermitExpiration());
    }

    @Test
    void testRegisterCarSetsPermitExpiration() {
        Car car = customer.register("ABC123", CarType.COMPACT);

        LocalDate expectedExpiration = LocalDate.now().plusYears(1);
        assertEquals(expectedExpiration, car.getPermitExpiration());
    }

    @Test
    void testRegisterCarAddsToCustomerList() {
        assertEquals(0, customer.getCars().size());

        Car car1 = customer.register("ABC123", CarType.COMPACT);
        assertEquals(1, customer.getCars().size());
        assertTrue(customer.getCars().contains(car1));

        Car car2 = customer.register("XYZ789", CarType.SUV);
        assertEquals(2, customer.getCars().size());
        assertTrue(customer.getCars().contains(car2));
    }

    @Test
    void testRegisterMultipleCars() {
        customer.register("ABC123", CarType.COMPACT);
        customer.register("DEF456", CarType.SUV);
        customer.register("GHI789", CarType.COMPACT);

        assertEquals(3, customer.getCars().size());
    }

    @Test
    void testGetCustomerId() {
        assertEquals("CUSTOMER-1", customer.getCustomerId());
    }

    @Test
    void testGetName() {
        assertEquals("John Doe", customer.getName());
    }

    @Test
    void testGetAddress() {
        assertEquals(address, customer.getAddress());
    }

    @Test
    void testGetPhoneNumber() {
        assertEquals("555-1234", customer.getPhoneNumber());
    }

    @Test
    void testGetCars() {
        assertNotNull(customer.getCars());
        assertTrue(customer.getCars().isEmpty());

        customer.register("ABC123", CarType.COMPACT);
        assertFalse(customer.getCars().isEmpty());
    }

    @Test
    void testToString() {
        String result = customer.toString();

        assertTrue(result.contains("customerId='CUSTOMER-1'"));
        assertTrue(result.contains("name='John Doe'"));
        assertTrue(result.contains("phoneNumber='555-1234'"));
        assertTrue(result.contains("123 Main St"));
    }

    @Test
    void testRegisterCarGeneratesUniquePermits() {
        Car car1 = customer.register("ABC123", CarType.COMPACT);
        Car car2 = customer.register("XYZ789", CarType.SUV);

        assertNotNull(car1.getPermit());
        assertNotNull(car2.getPermit());
        assertNotEquals(car1.getPermit(), car2.getPermit());
    }
}