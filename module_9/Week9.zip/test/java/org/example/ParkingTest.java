package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ParkingTest {

    @Test
    public void testAddress() {
        Address address = new Address("123 Main St", "Apt 4", "Boston", "MA", "02101");

        assertEquals("123 Main St", address.getStreetAddress1(), "Street address 1 mismatch");
        assertEquals("Apt 4", address.getStreetAddress2(), "Street address 2 mismatch");
        assertEquals("Boston", address.getCity(), "City mismatch");
        assertEquals("MA", address.getState(), "State mismatch");
        assertEquals("02101", address.getZipCode(), "Zip code mismatch");
        assertTrue(address.getAddressInfo().contains("Boston"), "Address info should contain city");
    }

    @Test
    public void testCarType() {
        assertEquals(2, CarType.values().length, "Should have exactly 2 car types");
    }

    @Test
    public void testMoney() {
        Money money1 = new Money(1000);

        assertEquals(1000, money1.getCents(), "Cents should be 1000");
        assertEquals(10.0, money1.getDollars(), "Dollars should be 10.0");

        Money money2 = new Money(15.50);
        assertEquals(1550, money2.getCents(), "Cents should be 1550");
        assertEquals(15.50, money2.getDollars(), 0.01, "Dollars should be approximately 15.50");
        assertEquals("$15.50", money2.toString(), "String representation should be $15.50");
    }

    @Test
    public void testCustomer() {
        Address address = new Address("456 Oak Ave", "", "Denver", "CO", "80202");
        Customer customer = new Customer("C001", "Alice Johnson", address, "303-555-1234");

        assertEquals("C001", customer.getCustomerId(), "Customer ID mismatch");
        assertEquals("Alice Johnson", customer.getName(), "Customer name mismatch");
        assertEquals("303-555-1234", customer.getPhoneNumber(), "Phone number mismatch");
        assertSame(address, customer.getAddress(), "Address should match");
        assertTrue(customer.getCars().isEmpty(), "New customer should have no cars");
    }

    @Test
    public void testCar() {
        Address address = new Address("789 Elm St", "", "Austin", "TX", "73301");
        Customer customer = new Customer("C002", "Bob Smith", address, "512-555-5678");

        Car car = customer.register("ABC123", CarType.COMPACT);

        assertNotNull(car, "Car should not be null");
        assertEquals("ABC123", car.getLicense(), "License should be ABC123");
        assertEquals(CarType.COMPACT, car.getType(), "Car type should be COMPACT");
        assertEquals("C002", car.getOwner(), "Owner should be C002");
        assertNotNull(car.getPermit(), "Permit should not be null");
        assertNotNull(car.getPermitExpiration(), "Permit expiration should not be null");
        assertEquals(1, customer.getCars().size(), "Customer should have 1 car");
        assertSame(car, customer.getCars().getFirst(), "Customer's car list should contain registered car");
    }

    @Test
    public void testParkingLot() {
        Address lotAddress = new Address("100 Parking Way", "", "Seattle", "WA", "98101");
        ParkingLot lot = new ParkingLot("LOT-1", lotAddress, 200);

        assertEquals("LOT-1", lot.getLotId(), "Lot ID mismatch");
        assertEquals(200, lot.getCapacity(), "Capacity should be 200");
        assertSame(lotAddress, lot.getAddress(), "Address should match");

        Address address = new Address("789 Elm St", "", "Austin", "TX", "73301");
        Customer customer = new Customer("C003", "Test User", address, "512-555-1111");
        Car car = customer.register("TEST123", CarType.SUV);
        lot.entry(car);
    }

    @Test
    public void testParkingCharge() {
        Money amount = new Money(8.50);
        Money expectedCost = new Money(8.50*.8);
        java.time.Instant now = java.time.Instant.now();
        ParkingCharge charge = new ParkingCharge("PERMIT-001", "LOT-A", now, amount, CarType.COMPACT);

        assertEquals("PERMIT-001", charge.getPermitId(), "Permit ID mismatch");
        assertEquals("LOT-A", charge.getLotId(), "Lot ID mismatch");
        assertSame(now, charge.getIncurred(), "Incurred time should match");
        assertEquals(expectedCost, charge.getAmount(), "Amount should match");
    }

    @Test
    public void testParkingOffice() {
        Address officeAddress = new Address("500 Admin Blvd", "", "Portland", "OR", "97201");
        ParkingOffice office = new ParkingOffice("City Parking Office", officeAddress);

        assertEquals("City Parking Office", office.getName(), "Office name mismatch");
        assertSame(officeAddress, office.getAddress(), "Office address should match");
        assertTrue(office.getCustomers().isEmpty(), "New office should have no customers");
        assertTrue(office.getCars().isEmpty(), "New office should have no cars");
        assertTrue(office.getLots().isEmpty(), "New office should have no lots");
        assertTrue(office.getCharges().isEmpty(), "New office should have no charges");

        Address custAddress = new Address("111 Student Ln", "", "Portland", "OR", "97202");
        Customer customer = office.register("Charlie Brown", custAddress, "503-555-9999");

        assertNotNull(customer, "Registered customer should not be null");
        assertEquals("Charlie Brown", customer.getName(), "Customer name should match");
        assertEquals(1, office.getCustomers().size(), "Office should have 1 customer");

        Car car = office.register(customer, "XYZ789", CarType.SUV);

        assertNotNull(car, "Registered car should not be null");
        assertEquals("XYZ789", car.getLicense(), "Car license should match");
        assertEquals(1, office.getCars().size(), "Office should have 1 car");

        Address lotAddress = new Address("200 Lot St", "", "Portland", "OR", "97203");
        ParkingLot lot = new ParkingLot("LOT-X", lotAddress, 100);
        office.addLot(lot);

        assertEquals(1, office.getLots().size(), "Office should have 1 lot");

        Money chargeAmount = new Money(10.00);
        ParkingCharge charge = new ParkingCharge(car.getPermit(), lot.getLotId(), java.time.Instant.now(), chargeAmount, car.getType());
        Money returnedAmount = office.addCharge(charge);

        assertSame(chargeAmount, returnedAmount, "Returned charge amount should match");
        assertEquals(1, office.getCharges().size(), "Office should have 1 charge");

        Customer found = office.getCustomer("Charlie Brown");
        assertNotNull(found, "Should find customer by name");
        assertSame(customer, found, "Found customer should be the same object");

        Customer notFound = office.getCustomer("Non Existent");
        assertNull(notFound, "Should return null for non-existent customer");
    }
}