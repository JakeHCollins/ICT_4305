package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import static org.junit.jupiter.api.Assertions.*;

class ParkingLotTest {

    private ParkingLot parkingLot;
    private Address address;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @BeforeEach
    void setUp() {
        address = new Address(
                "100 Parking Way",
                null,
                "Chicago",
                "IL",
                "60601"
        );
        parkingLot = new ParkingLot("LOT-A", address, 100);

        // Redirect System.out to capture console output
        System.setOut(new PrintStream(outContent));
    }

    @AfterEach
    void tearDown() {
        // Restore original System.out
        System.setOut(originalOut);
    }

    @Test
    void testConstructor() {
        assertNotNull(parkingLot);
        assertEquals("LOT-A", parkingLot.getLotId());
        assertEquals(address, parkingLot.getAddress());
        assertEquals(100, parkingLot.getCapacity());
    }

    @Test
    void testGetLotId() {
        assertEquals("LOT-A", parkingLot.getLotId());
    }

    @Test
    void testGetAddress() {
        assertEquals(address, parkingLot.getAddress());
    }

    @Test
    void testGetCapacity() {
        assertEquals(100, parkingLot.getCapacity());
    }

    @Test
    void testEntry() {
        Car car = new Car("ABC123", CarType.COMPACT, "CUSTOMER-1");

        parkingLot.entry(car);

        String output = outContent.toString();
        assertTrue(output.contains("Car ABC123 entered parking lot LOT-A"));
    }

    @Test
    void testEntryMultipleCars() {
        Car car1 = new Car("ABC123", CarType.COMPACT, "CUSTOMER-1");
        Car car2 = new Car("XYZ789", CarType.SUV, "CUSTOMER-2");

        parkingLot.entry(car1);
        parkingLot.entry(car2);

        String output = outContent.toString();
        assertTrue(output.contains("Car ABC123 entered parking lot LOT-A"));
        assertTrue(output.contains("Car XYZ789 entered parking lot LOT-A"));
    }

    @Test
    void testToString() {
        String result = parkingLot.toString();

        assertTrue(result.contains("lotId='LOT-A'"));
        assertTrue(result.contains("capacity=100"));
        assertTrue(result.contains("100 Parking Way"));
        assertTrue(result.contains("Chicago"));
    }

    @Test
    void testToStringWithCompleteAddress() {
        Address detailedAddress = new Address(
                "200 Main St",
                "Suite 100",
                "Springfield",
                "IL",
                "62701"
        );
        ParkingLot lot = new ParkingLot("LOT-B", detailedAddress, 50);

        String result = lot.toString();
        assertTrue(result.contains("lotId='LOT-B'"));
        assertTrue(result.contains("capacity=50"));
        assertTrue(result.contains("200 Main St"));
        assertTrue(result.contains("Suite 100"));
    }

    @Test
    void testDifferentCapacities() {
        ParkingLot smallLot = new ParkingLot("LOT-SMALL", address, 10);
        ParkingLot largeLot = new ParkingLot("LOT-LARGE", address, 500);

        assertEquals(10, smallLot.getCapacity());
        assertEquals(500, largeLot.getCapacity());
    }

    @Test
    void testZeroCapacity() {
        ParkingLot emptyLot = new ParkingLot("LOT-EMPTY", address, 0);
        assertEquals(0, emptyLot.getCapacity());
    }
}