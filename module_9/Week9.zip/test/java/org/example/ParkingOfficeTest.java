package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.time.Instant;
import static org.junit.jupiter.api.Assertions.*;

class ParkingOfficeTest {

    private ParkingOffice parkingOffice;
    private Address officeAddress;

    @BeforeEach
    void setUp() {
        officeAddress = new Address(
                "500 Admin Blvd",
                "Floor 3",
                "Chicago",
                "IL",
                "60601"
        );
        parkingOffice = new ParkingOffice("Downtown Parking", officeAddress);
    }

    @Test
    void testConstructor() {
        assertNotNull(parkingOffice);
        assertEquals("Downtown Parking", parkingOffice.getName());
        assertEquals(officeAddress, parkingOffice.getAddress());
        assertNotNull(parkingOffice.getCustomers());
        assertNotNull(parkingOffice.getCars());
        assertNotNull(parkingOffice.getLots());
        assertNotNull(parkingOffice.getCharges());
        assertTrue(parkingOffice.getCustomers().isEmpty());
        assertTrue(parkingOffice.getCars().isEmpty());
        assertTrue(parkingOffice.getLots().isEmpty());
        assertTrue(parkingOffice.getCharges().isEmpty());
    }

    @Test
    void testRegisterCustomer() {
        Address customerAddress = new Address(
                "123 Main St",
                null,
                "Springfield",
                "IL",
                "62701"
        );

        Customer customer = parkingOffice.register("John Doe", customerAddress, "555-1234");

        assertNotNull(customer);
        assertEquals("CUSTOMER-1", customer.getCustomerId());
        assertEquals("John Doe", customer.getName());
        assertEquals(customerAddress, customer.getAddress());
        assertEquals("555-1234", customer.getPhoneNumber());
        assertEquals(1, parkingOffice.getCustomers().size());
        assertTrue(parkingOffice.getCustomers().contains(customer));
    }

    @Test
    void testRegisterMultipleCustomers() {
        Address addr1 = new Address("123 St", null, "City1", "IL", "60601");
        Address addr2 = new Address("456 Ave", null, "City2", "IL", "60602");

        Customer customer1 = parkingOffice.register("Alice", addr1, "555-0001");
        Customer customer2 = parkingOffice.register("Bob", addr2, "555-0002");

        assertEquals("CUSTOMER-1", customer1.getCustomerId());
        assertEquals("CUSTOMER-2", customer2.getCustomerId());
        assertEquals(2, parkingOffice.getCustomers().size());
    }

    @Test
    void testRegisterCar() {
        Address customerAddress = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", customerAddress, "555-1234");

        Car car = parkingOffice.register(customer, "ABC123", CarType.COMPACT);

        assertNotNull(car);
        assertEquals("ABC123", car.getLicense());
        assertEquals(CarType.COMPACT, car.getType());
        assertEquals("CUSTOMER-1", car.getOwner());
        assertNotNull(car.getPermit());
        assertNotNull(car.getPermitExpiration());
        assertEquals(1, parkingOffice.getCars().size());
        assertTrue(parkingOffice.getCars().contains(car));
        assertEquals(1, customer.getCars().size());
    }

    @Test
    void testRegisterMultipleCarsForCustomer() {
        Address customerAddress = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", customerAddress, "555-1234");

        Car car1 = parkingOffice.register(customer, "ABC123", CarType.COMPACT);
        Car car2 = parkingOffice.register(customer, "XYZ789", CarType.SUV);

        assertEquals(2, parkingOffice.getCars().size());
        assertEquals(2, customer.getCars().size());
    }

    @Test
    void testGetCustomerByName() {
        Address addr = new Address("123 St", null, "City", "IL", "60601");
        parkingOffice.register("John Doe", addr, "555-1234");
        parkingOffice.register("Jane Smith", addr, "555-5678");

        Customer found = parkingOffice.getCustomer("John Doe");
        assertNotNull(found);
        assertEquals("John Doe", found.getName());
        assertEquals("CUSTOMER-1", found.getCustomerId());
    }

    @Test
    void testGetCustomerNotFound() {
        Customer notFound = parkingOffice.getCustomer("Nonexistent Customer");
        assertNull(notFound);
    }

    @Test
    void testGetCustomerWithMultipleCustomers() {
        Address addr = new Address("123 St", null, "City", "IL", "60601");
        parkingOffice.register("Alice", addr, "555-0001");
        parkingOffice.register("Bob", addr, "555-0002");
        parkingOffice.register("Charlie", addr, "555-0003");

        Customer found = parkingOffice.getCustomer("Bob");
        assertNotNull(found);
        assertEquals("Bob", found.getName());
        assertEquals("CUSTOMER-2", found.getCustomerId());
    }

    @Test
    void testAddCharge() {
        Money amount = new Money(1000);
        Instant now = Instant.now();
        ParkingCharge charge = new ParkingCharge(
                "PERMIT-123",
                "LOT-A",
                now,
                amount,
                CarType.COMPACT
        );

        Money chargedAmount = parkingOffice.addCharge(charge);

        assertNotNull(chargedAmount);
        assertEquals(1, parkingOffice.getCharges().size());
        assertTrue(parkingOffice.getCharges().contains(charge));
        assertEquals(800, chargedAmount.getCents());
    }

    @Test
    void testAddMultipleCharges() {
        Money amount1 = new Money(1000);
        Money amount2 = new Money(1500);
        Instant now = Instant.now();

        ParkingCharge charge1 = new ParkingCharge("PERMIT-1", "LOT-A", now, amount1, CarType.COMPACT);
        ParkingCharge charge2 = new ParkingCharge("PERMIT-2", "LOT-B", now, amount2, CarType.SUV);

        parkingOffice.addCharge(charge1);
        parkingOffice.addCharge(charge2);

        assertEquals(2, parkingOffice.getCharges().size());
    }

    @Test
    void testAddLot() {
        Address lotAddress = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        ParkingLot lot = new ParkingLot("LOT-A", lotAddress, 100);

        parkingOffice.addLot(lot);

        assertEquals(1, parkingOffice.getLots().size());
        assertTrue(parkingOffice.getLots().contains(lot));
    }

    @Test
    void testAddMultipleLots() {
        Address addr1 = new Address("100 Way", null, "City", "IL", "60601");
        Address addr2 = new Address("200 Ave", null, "City", "IL", "60602");

        ParkingLot lot1 = new ParkingLot("LOT-A", addr1, 100);
        ParkingLot lot2 = new ParkingLot("LOT-B", addr2, 150);

        parkingOffice.addLot(lot1);
        parkingOffice.addLot(lot2);

        assertEquals(2, parkingOffice.getLots().size());
    }

    @Test
    void testGetName() {
        assertEquals("Downtown Parking", parkingOffice.getName());
    }

    @Test
    void testGetAddress() {
        assertEquals(officeAddress, parkingOffice.getAddress());
    }

    @Test
    void testGetCustomers() {
        assertTrue(parkingOffice.getCustomers().isEmpty());

        Address addr = new Address("123 St", null, "City", "IL", "60601");
        parkingOffice.register("John Doe", addr, "555-1234");

        assertFalse(parkingOffice.getCustomers().isEmpty());
        assertEquals(1, parkingOffice.getCustomers().size());
    }

    @Test
    void testGetCars() {
        assertTrue(parkingOffice.getCars().isEmpty());

        Address addr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", addr, "555-1234");
        parkingOffice.register(customer, "ABC123", CarType.COMPACT);

        assertFalse(parkingOffice.getCars().isEmpty());
        assertEquals(1, parkingOffice.getCars().size());
    }

    @Test
    void testGetLots() {
        assertTrue(parkingOffice.getLots().isEmpty());

        Address lotAddr = new Address("100 Way", null, "City", "IL", "60601");
        ParkingLot lot = new ParkingLot("LOT-A", lotAddr, 100);
        parkingOffice.addLot(lot);

        assertFalse(parkingOffice.getLots().isEmpty());
        assertEquals(1, parkingOffice.getLots().size());
    }

    @Test
    void testGetCharges() {
        assertTrue(parkingOffice.getCharges().isEmpty());

        Money amount = new Money(1000);
        ParkingCharge charge = new ParkingCharge(
                "PERMIT-1",
                "LOT-A",
                Instant.now(),
                amount,
                CarType.COMPACT
        );
        parkingOffice.addCharge(charge);

        assertFalse(parkingOffice.getCharges().isEmpty());
        assertEquals(1, parkingOffice.getCharges().size());
    }

    @Test
    void testCompleteWorkflow() {
        Address customerAddr = new Address("123 Main St", null, "Springfield", "IL", "62701");
        Customer customer = parkingOffice.register("John Doe", customerAddr, "555-1234");

        Car car = parkingOffice.register(customer, "ABC123", CarType.COMPACT);

        Address lotAddr = new Address("100 Parking Way", null, "Chicago", "IL", "60601");
        ParkingLot lot = new ParkingLot("LOT-A", lotAddr, 100);
        parkingOffice.addLot(lot);

        Money amount = new Money(1000);
        ParkingCharge charge = new ParkingCharge(
                car.getPermit(),
                lot.getLotId(),
                Instant.now(),
                amount,
                car.getType()
        );
        Money chargedAmount = parkingOffice.addCharge(charge);

        assertEquals(1, parkingOffice.getCustomers().size());
        assertEquals(1, parkingOffice.getCars().size());
        assertEquals(1, parkingOffice.getLots().size());
        assertEquals(1, parkingOffice.getCharges().size());
        assertEquals(800, chargedAmount.getCents());
    }

    @Test
    void testGetCustomerIds() {
        // Initially empty
        assertTrue(parkingOffice.getCustomerIds().isEmpty());

        Address addr1 = new Address("123 St", null, "City", "IL", "60601");
        Address addr2 = new Address("456 Ave", null, "City", "IL", "60602");

        Customer customer1 = parkingOffice.register("Alice", addr1, "555-0001");
        Customer customer2 = parkingOffice.register("Bob", addr2, "555-0002");

        var customerIds = parkingOffice.getCustomerIds();
        assertEquals(2, customerIds.size());
        assertTrue(customerIds.contains("CUSTOMER-1"));
        assertTrue(customerIds.contains("CUSTOMER-2"));
        assertEquals("CUSTOMER-1", customer1.getCustomerId());
        assertEquals("CUSTOMER-2", customer2.getCustomerId());
    }

    @Test
    void testGetPermitIds() {
        // Initially empty
        assertTrue(parkingOffice.getPermitIds().isEmpty());

        Address addr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", addr, "555-1234");

        Car car1 = parkingOffice.register(customer, "ABC123", CarType.COMPACT);
        Car car2 = parkingOffice.register(customer, "XYZ789", CarType.SUV);

        var permitIds = parkingOffice.getPermitIds();
        assertEquals(2, permitIds.size());
        assertTrue(permitIds.contains(car1.getPermit()));
        assertTrue(permitIds.contains(car2.getPermit()));
    }

    @Test
    void testGetPermitIdsMultipleCustomers() {
        Address addr1 = new Address("123 St", null, "City", "IL", "60601");
        Address addr2 = new Address("456 Ave", null, "City", "IL", "60602");

        Customer customer1 = parkingOffice.register("Alice", addr1, "555-0001");
        Customer customer2 = parkingOffice.register("Bob", addr2, "555-0002");

        Car car1 = parkingOffice.register(customer1, "ABC123", CarType.COMPACT);
        Car car2 = parkingOffice.register(customer1, "DEF456", CarType.SUV);
        Car car3 = parkingOffice.register(customer2, "GHI789", CarType.COMPACT);

        var permitIds = parkingOffice.getPermitIds();
        assertEquals(3, permitIds.size());
        assertTrue(permitIds.contains(car1.getPermit()));
        assertTrue(permitIds.contains(car2.getPermit()));
        assertTrue(permitIds.contains(car3.getPermit()));
    }

    @Test
    void testGetPermitIdsForSpecificCustomer() {
        Address addr1 = new Address("123 St", null, "City", "IL", "60601");
        Address addr2 = new Address("456 Ave", null, "City", "IL", "60602");

        Customer customer1 = parkingOffice.register("Alice", addr1, "555-0001");
        Customer customer2 = parkingOffice.register("Bob", addr2, "555-0002");

        Car car1 = parkingOffice.register(customer1, "ABC123", CarType.COMPACT);
        Car car2 = parkingOffice.register(customer1, "DEF456", CarType.SUV);
        Car car3 = parkingOffice.register(customer2, "GHI789", CarType.COMPACT);

        var customer1PermitIds = parkingOffice.getPermitIds(customer1);
        assertEquals(2, customer1PermitIds.size());
        assertTrue(customer1PermitIds.contains(car1.getPermit()));
        assertTrue(customer1PermitIds.contains(car2.getPermit()));
        assertFalse(customer1PermitIds.contains(car3.getPermit()));

        var customer2PermitIds = parkingOffice.getPermitIds(customer2);
        assertEquals(1, customer2PermitIds.size());
        assertTrue(customer2PermitIds.contains(car3.getPermit()));
        assertFalse(customer2PermitIds.contains(car1.getPermit()));
        assertFalse(customer2PermitIds.contains(car2.getPermit()));
    }

    @Test
    void testGetPermitIdsForCustomerWithNoCars() {
        Address addr = new Address("123 St", null, "City", "IL", "60601");
        Customer customer = parkingOffice.register("John Doe", addr, "555-1234");

        var permitIds = parkingOffice.getPermitIds(customer);
        assertTrue(permitIds.isEmpty());
    }

    @Test
    void testGetPermitIdsForNullCustomer() {
        var permitIds = parkingOffice.getPermitIds(null);
        assertNotNull(permitIds);
        assertTrue(permitIds.isEmpty());
    }
}